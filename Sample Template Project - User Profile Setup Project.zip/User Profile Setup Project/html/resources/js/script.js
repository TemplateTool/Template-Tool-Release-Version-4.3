$(document).ready(function () {
    var i = 1;
    $(".add_row_button").click(add_row);
    $(".remove_row_button").click(remove_row);

    function add_row() {
        var table = $(this).closest('td').parent().closest("table");
        var row = table.find("tr.template").clone();
        row = row.find("input").each(function () {
            $(this).attr('id', $(this).attr('id') + i);
            $(this).attr('name', $(this).attr('name') + i);
        }).end();
        row.appendTo(table);
        var extra = row.height();
        row.css('display', '').attr('class', '');
        var parents = table.parents();
        if (!isNullOrUndefined(parents) && parents.length) {
            parents.each(function () {
                $(this).height($(this).height() + extra);
            });
        }
        row.find("input.add_row_button").bind("click", add_row);
        row.find("input.remove_row_button").bind("click", remove_row);
        i++;
        var children = table.closest('div.page').children();
        children.each(function () {
            if ($(this).offset().top > table.offset().top) {
                var offset = $(this).offset();
                $(this).offset({top: offset.top + extra, left: offset.left});
            }
        });
    }

    function remove_row() {
        var table = $(this).closest('td').parent().closest("table");
        var rows = table.find('tr').length - 1;
        if (rows <= 2) {
            return false;
        }
        var row = $(this).closest('tr');
        var row_height = row.height();
        var table_height = table.height();
        row.remove();
        table.height(table_height - row_height);
        var parents = table.parents();
        if (!isNullOrUndefined(parents) && parents.length) {
            parents.each(function () {
                $(this).height($(this).height() - row_height);
            });
        }
        var children = table.closest('div.page').children();
        children.each(function () {
            if ($(this).offset().top > table.offset().top) {
                var offset = $(this).offset();
                $(this).offset({top: offset.top - row_height, left: offset.left});
            }
        });
    }

    function isNullOrUndefined(a) {
        var rc = false;
        if (a === null || typeof (a) === "undefined") {
            rc = true;
        }

        return rc;
    }
    
    function enable(component) {
        component.removeAttr('disabled');
    }
    
    function disable(component) {
        component.attr('disabled', 'disabled');
    }

    $(".textbox_integer").keypress(function (evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode;
        if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        } else {
            if (charCode == 45) {
                if (this.value.startsWith("-")) {
                    this.value = this.value.substring(1);
                    return false;
                } else {
                    this.value = "-" + this.value;
                    return false;
                }
            }
            return true;
        }
    });

    $(".textbox_decimal").keypress(function (evt) { 
        var charCode = (evt.which) ? evt.which : event.keyCode;
        if (charCode != 45 && charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        } else {
            if (charCode == 45) {
                if (this.value.startsWith("-")) {
                    this.value = this.value.substring(1);
                    return false;
                } else {
                    this.value = "-" + this.value;
                    return false;
                }
            } else if (charCode == 46) {
                if (this.value.indexOf(".") >= 0) {
                    return false;
                }
            }
            return true;
        }
    });
    
    
    
    $("#0eedd8e2-80fe-49f4-87d0-19f7c361d656").bind("click", function(){
    if( $("#3da21cd8-5198-430b-8363-d2969958c97f").val() ==""  ) {
    $("#392fa6d9-c7dd-4adf-a92b-5a74f1ae1822, label[for=\"392fa6d9-c7dd-4adf-a92b-5a74f1ae1822\"]").show();



}

else if ( $("#69ab3a9c-47c7-4ad7-8a9b-0387293aff6d").val() ==""  ) {
    $("#c40b5876-ff9e-41f1-9237-3bdc60b61661, label[for=\"c40b5876-ff9e-41f1-9237-3bdc60b61661\"]").show();



}

else if ( $("#d54c05ed-db30-4a64-b8a1-f8098c685d11").val() ==""  ) {
    $("#bf6ae06f-cadf-4446-99a0-6e751f58d924, label[for=\"bf6ae06f-cadf-4446-99a0-6e751f58d924\"]").show();



}

else if ( $("#4d6a7858-40ee-4319-a1cb-dd0a032dc410").val() ==""  ) {
    $("#7cb53295-f137-4ca3-a970-ebc0131c7dbc, label[for=\"7cb53295-f137-4ca3-a970-ebc0131c7dbc\"]").show();



}

else if ( $("#c7f962e6-b6c3-4adc-836a-34ed3383de8c").val() ==""  ) {
    $("#27c57f72-5588-4276-a00a-6e0e1c6c04b1, label[for=\"27c57f72-5588-4276-a00a-6e0e1c6c04b1\"]").show();



}

else {
    $("#392fa6d9-c7dd-4adf-a92b-5a74f1ae1822, label[for=\"392fa6d9-c7dd-4adf-a92b-5a74f1ae1822\"]").hide();


$("#0afffbc5-cc50-4504-b573-a21e2e17d1dd, label[for=\"0afffbc5-cc50-4504-b573-a21e2e17d1dd\"]").hide();


$("#3e3a07b7-e43e-4dfe-b073-29a251ca79f3, label[for=\"3e3a07b7-e43e-4dfe-b073-29a251ca79f3\"]").show();


$("#c40b5876-ff9e-41f1-9237-3bdc60b61661, label[for=\"c40b5876-ff9e-41f1-9237-3bdc60b61661\"]").hide();


$("#bf6ae06f-cadf-4446-99a0-6e751f58d924, label[for=\"bf6ae06f-cadf-4446-99a0-6e751f58d924\"]").hide();


$("#7cb53295-f137-4ca3-a970-ebc0131c7dbc, label[for=\"7cb53295-f137-4ca3-a970-ebc0131c7dbc\"]").hide();


$("#27c57f72-5588-4276-a00a-6e0e1c6c04b1, label[for=\"27c57f72-5588-4276-a00a-6e0e1c6c04b1\"]").hide();



}


});



$("#29759db4-56ff-4628-b097-01f3042c4103").bind("click", function(){
    if( $("#9ebc6042-dd65-473b-9160-c96c6bf11130").val() =="Please Select"  ) {
    $("#04cca285-8dd1-4895-833d-58c20c95cb8c, label[for=\"04cca285-8dd1-4895-833d-58c20c95cb8c\"]").show();



}

else if ( $("#cae52a34-4cd4-4219-9e09-cbec1b060fbf").val() =="Please Select"  ) {
    $("#69a51e2e-7ed7-4e15-bc22-6be740218bfa, label[for=\"69a51e2e-7ed7-4e15-bc22-6be740218bfa\"]").show();



}

else if ( $("#f592f632-bbe1-408c-910b-c8feba6a5844").val() =="Please Select"  ) {
    $("#8bae709e-303d-4e6d-869f-51efc3f7514c, label[for=\"8bae709e-303d-4e6d-869f-51efc3f7514c\"]").show();



}

else if ( $("#1fb9bc41-a1fc-4fc7-8a66-8e0ce01304da").val() =="Please Select"  ) {
    $("#d515e0cb-86a2-49c3-a415-6bfc06e09825, label[for=\"d515e0cb-86a2-49c3-a415-6bfc06e09825\"]").show();



}

else {
    $("#8bae709e-303d-4e6d-869f-51efc3f7514c, label[for=\"8bae709e-303d-4e6d-869f-51efc3f7514c\"]").hide();


$("#d515e0cb-86a2-49c3-a415-6bfc06e09825, label[for=\"d515e0cb-86a2-49c3-a415-6bfc06e09825\"]").hide();


$("#3e3a07b7-e43e-4dfe-b073-29a251ca79f3, label[for=\"3e3a07b7-e43e-4dfe-b073-29a251ca79f3\"]").hide();


$("#1da45ecd-f7d8-4450-9f4b-b0256efd85f5, label[for=\"1da45ecd-f7d8-4450-9f4b-b0256efd85f5\"]").show();


$("#04cca285-8dd1-4895-833d-58c20c95cb8c, label[for=\"04cca285-8dd1-4895-833d-58c20c95cb8c\"]").hide();


$("#04cca285-8dd1-4895-833d-58c20c95cb8c, label[for=\"04cca285-8dd1-4895-833d-58c20c95cb8c\"]").hide();


$("#69a51e2e-7ed7-4e15-bc22-6be740218bfa, label[for=\"69a51e2e-7ed7-4e15-bc22-6be740218bfa\"]").hide();



}


});


$("#10ca8b62-625c-4ec7-bc01-b71460eb30fb").bind("click", function(){
    $("#3e3a07b7-e43e-4dfe-b073-29a251ca79f3, label[for=\"3e3a07b7-e43e-4dfe-b073-29a251ca79f3\"]").hide();

$("#0afffbc5-cc50-4504-b573-a21e2e17d1dd, label[for=\"0afffbc5-cc50-4504-b573-a21e2e17d1dd\"]").show();


});



$("#9a4df77e-b9af-4cfb-b919-48d441041618").bind("click", function(){
    if( $("#22dc9f62-7cf3-4b33-9a5f-4fa79dd745cf").val() =="Please Select"  ) {
    $("#c81085a6-6b85-4adc-a078-3c3d99dd6043, label[for=\"c81085a6-6b85-4adc-a078-3c3d99dd6043\"]").show();



}

else if ( $("#4d8f78b5-0eaf-4c84-ab86-d4ffe1325b10").val() ==""  ) {
    $("#d4f5c453-9be3-481c-a561-9bef0c52c127, label[for=\"d4f5c453-9be3-481c-a561-9bef0c52c127\"]").show();



}

else if ( $("#7cbbd861-67a4-4191-9913-2801d723619c").val() ==""  ) {
    $("#ece34e63-ab30-4676-9a64-ff9abbf87541, label[for=\"ece34e63-ab30-4676-9a64-ff9abbf87541\"]").show();



}

else {
    $("#c81085a6-6b85-4adc-a078-3c3d99dd6043, label[for=\"c81085a6-6b85-4adc-a078-3c3d99dd6043\"]").hide();


$("#d4f5c453-9be3-481c-a561-9bef0c52c127, label[for=\"d4f5c453-9be3-481c-a561-9bef0c52c127\"]").hide();


$("#ece34e63-ab30-4676-9a64-ff9abbf87541, label[for=\"ece34e63-ab30-4676-9a64-ff9abbf87541\"]").hide();


$("#1da45ecd-f7d8-4450-9f4b-b0256efd85f5, label[for=\"1da45ecd-f7d8-4450-9f4b-b0256efd85f5\"]").hide();


$("#393a47da-8047-44e5-81e8-ad84d4f26769, label[for=\"393a47da-8047-44e5-81e8-ad84d4f26769\"]").show();



}


});


$("#925885ee-b55a-4e00-ac7b-8d4866b64df7").bind("click", function(){
    $("#1da45ecd-f7d8-4450-9f4b-b0256efd85f5, label[for=\"1da45ecd-f7d8-4450-9f4b-b0256efd85f5\"]").hide();

$("#3e3a07b7-e43e-4dfe-b073-29a251ca79f3, label[for=\"3e3a07b7-e43e-4dfe-b073-29a251ca79f3\"]").show();


});



$("#04f55888-123b-4f1d-b1c8-4714f31de440").bind("click", function(){
    if( $("#aef1f2ff-602c-4e6f-84aa-d0240ccc7f7b").val() ==""  ) {
    $("#d6013b71-bc91-4f23-b8ee-ada4bbcf7826, label[for=\"d6013b71-bc91-4f23-b8ee-ada4bbcf7826\"]").show();



}

else if ( $("#ca417189-e648-454d-b02c-519794121e9e").val() ==""  ) {
    $("#ff3d491c-1b08-4d4c-affd-1440c89d7be9, label[for=\"ff3d491c-1b08-4d4c-affd-1440c89d7be9\"]").show();



}

else {
    $("#d6013b71-bc91-4f23-b8ee-ada4bbcf7826, label[for=\"d6013b71-bc91-4f23-b8ee-ada4bbcf7826\"]").hide();


$("#ff3d491c-1b08-4d4c-affd-1440c89d7be9, label[for=\"ff3d491c-1b08-4d4c-affd-1440c89d7be9\"]").hide();


$("#393a47da-8047-44e5-81e8-ad84d4f26769, label[for=\"393a47da-8047-44e5-81e8-ad84d4f26769\"]").hide();


$("#6fd8972e-b08c-4eff-8d02-e536fbdd2ec0, label[for=\"6fd8972e-b08c-4eff-8d02-e536fbdd2ec0\"]").show();



}


});


$("#f7279c69-2f03-4a56-b72e-6680943cd364").bind("click", function(){
    $("#1da45ecd-f7d8-4450-9f4b-b0256efd85f5, label[for=\"1da45ecd-f7d8-4450-9f4b-b0256efd85f5\"]").show();

$("#393a47da-8047-44e5-81e8-ad84d4f26769, label[for=\"393a47da-8047-44e5-81e8-ad84d4f26769\"]").hide();


});





});

